import os
import telebot

# BOT_TOKEN environment variable must be set in Railway Variables
BOT_TOKEN = os.getenv("BOT_TOKEN")

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN environment variable not set!")

bot = telebot.TeleBot(BOT_TOKEN)

@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(
        message,
        "👋 Salom! Men Kafisent Botman. Tez orada Bulldrop ranglarini tahlil qilaman!")

@bot.message_handler(commands=['predict'])
def predict_next(message):
    bot.reply_to(message, "🔮 Taxmin: (demo) QIZIL")

@bot.message_handler(func=lambda m: True)
def echo_all(message):
    bot.reply_to(message, "⏳ Hozircha test holatdaman.")

if __name__ == '__main__':
    print("Bot is polling...")
    bot.infinity_polling()
